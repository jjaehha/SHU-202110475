package chapter1;

public class ��������while�� {

	public static void main(String[] args) {
		int i = 0;
		int sum=0;
		while (i <= 10) {
			//System.out.println(i);
			i=i+1;
			sum=sum+i;
		}
		System.out.print(sum);
	}

}
